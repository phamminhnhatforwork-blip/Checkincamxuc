/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { WelcomeScreen } from './components/WelcomeScreen';
import { QuestionCard } from './components/QuestionCard';
import { SummaryScreen } from './components/SummaryScreen';
import { HistoryModal } from './components/HistoryModal';
import { QUESTIONS_DATA } from './data/questions';
import { QuestionAnswer, CheckInRecord } from './types';
import { Sprout, History, Home } from 'lucide-react';

const STORAGE_KEY = 'emotion_checkin_history_v1';

export default function App() {
  const [view, setView] = useState<'welcome' | 'question' | 'summary'>('welcome');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [answers, setAnswers] = useState<Record<number, QuestionAnswer>>({});
  const [history, setHistory] = useState<CheckInRecord[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);

  // Load history from localStorage
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setHistory(JSON.parse(stored));
      }
    } catch {
      // Ignore storage error
    }
  }, []);

  // Save history to localStorage
  const saveToHistory = (newAnswers: Record<number, QuestionAnswer>) => {
    try {
      const q1Ans = newAnswers[1]?.selectedOptionIds[0];
      const q1Option = QUESTIONS_DATA[0].options.find((o) => o.id === q1Ans);
      const intensity =
        newAnswers[5]?.scaleValue || Number(newAnswers[5]?.selectedOptionIds[0]) || 5;

      const newRecord: CheckInRecord = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        answers: newAnswers,
        primaryMood: q1Option ? `${q1Option.emoji || ''} ${q1Option.label}`.trim() : undefined,
        intensity,
      };

      const updated = [newRecord, ...history].slice(0, 30);
      setHistory(updated);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch {
      // Ignore storage error
    }
  };

  const handleStart = () => {
    // Reset answers for new session
    setAnswers({});
    setCurrentQuestionIndex(0);
    setView('question');
  };

  const handleUpdateAnswer = (answer: QuestionAnswer) => {
    setAnswers((prev) => ({
      ...prev,
      [answer.questionId]: answer,
    }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < QUESTIONS_DATA.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
    } else {
      // Final question answered: save and go to summary
      saveToHistory(answers);
      setView('summary');
    }
  };

  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
    } else {
      setView('welcome');
    }
  };

  const handleRestart = () => {
    setAnswers({});
    setCurrentQuestionIndex(0);
    setView('welcome');
  };

  const handleSelectHistoryRecord = (record: CheckInRecord) => {
    setAnswers(record.answers);
    setView('summary');
  };

  const handleClearHistory = () => {
    if (window.confirm('Bạn có chắc chắn muốn xóa toàn bộ lịch sử check-in không?')) {
      setHistory([]);
      localStorage.removeItem(STORAGE_KEY);
    }
  };

  const currentQuestion = QUESTIONS_DATA[currentQuestionIndex];
  const currentAnswer: QuestionAnswer = answers[currentQuestion.id] || {
    questionId: currentQuestion.id,
    selectedOptionIds: currentQuestion.type === 'scale' ? ['5'] : [],
    feedbackNote: '',
    scaleValue: currentQuestion.type === 'scale' ? 5 : undefined,
  };

  return (
    <div className="min-h-screen bg-[#ecf2ed] flex flex-col justify-between text-[#1b2b21] selection:bg-[#477a59]/20 selection:text-[#1b2b21] relative overflow-x-hidden">
      {/* Subtle organic ambient background glows */}
      <div className="fixed top-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-[#e3ede5] to-transparent rounded-full blur-3xl pointer-events-none -z-10 opacity-70" />
      <div className="fixed -bottom-20 right-0 w-96 h-96 bg-[#e1ece3] rounded-full blur-3xl pointer-events-none -z-10 opacity-60" />

      {/* Minimal Top Brand Bar */}
      <header className="w-full border-b border-[#e1eae2]/70 bg-[#ecf2ed]/80 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 h-14 flex items-center justify-between">
          {/* Brand zone */}
          <button
            onClick={() => setView('welcome')}
            className="flex items-center gap-2 text-sm font-bold text-[#1b2f22] tracking-tight hover:opacity-85 transition-opacity cursor-pointer"
          >
            <span className="w-7 h-7 rounded-xl bg-[#dfeae1] flex items-center justify-center text-[#3e724f]">
              <Sprout className="w-4 h-4" />
            </span>
            <span>Check-in Cảm Xúc</span>
          </button>

          {/* Actions zone */}
          <div className="flex items-center gap-2">
            {view !== 'welcome' && (
              <button
                onClick={() => setView('welcome')}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#46604d] hover:bg-[#dfeae1] rounded-xl transition-colors cursor-pointer"
                title="Về trang bắt đầu"
              >
                <Home className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Trang chủ</span>
              </button>
            )}

            <button
              onClick={() => setIsHistoryOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-[#3b5943] bg-white/70 hover:bg-white border border-[#d6e3d8] rounded-xl transition-all shadow-2xs cursor-pointer"
            >
              <History className="w-3.5 h-3.5" />
              <span>Lịch sử ({history.length})</span>
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col justify-center">
        {view === 'welcome' && (
          <WelcomeScreen
            onStart={handleStart}
            onOpenHistory={() => setIsHistoryOpen(true)}
            historyCount={history.length}
          />
        )}

        {view === 'question' && (
          <QuestionCard
            question={currentQuestion}
            totalQuestions={QUESTIONS_DATA.length}
            currentAnswer={currentAnswer}
            onUpdateAnswer={handleUpdateAnswer}
            onNext={handleNext}
            onPrev={handlePrev}
            isFirst={currentQuestionIndex === 0}
            isLast={currentQuestionIndex === QUESTIONS_DATA.length - 1}
          />
        )}

        {view === 'summary' && (
          <SummaryScreen answers={answers} onRestart={handleRestart} />
        )}
      </main>

      {/* Simple quiet footer */}
      <footer className="w-full py-4 text-center text-xs text-[#708676] border-t border-[#e2ece4]/60">
        <p>Lắng nghe và thấu hiểu cảm xúc mỗi ngày · Bình an từ bên trong 🌱</p>
      </footer>

      {/* Past check-in history modal */}
      <HistoryModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        records={history}
        onSelectRecord={handleSelectHistoryRecord}
        onClearHistory={handleClearHistory}
      />
    </div>
  );
}
