import React from 'react';
import { X, Calendar, Clock, Trash2, ArrowRight } from 'lucide-react';
import { CheckInRecord } from '../types';
import { QUESTIONS_DATA } from '../data/questions';

interface HistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  records: CheckInRecord[];
  onSelectRecord: (record: CheckInRecord) => void;
  onClearHistory: () => void;
}

export const HistoryModal: React.FC<HistoryModalProps> = ({
  isOpen,
  onClose,
  records,
  onSelectRecord,
  onClearHistory,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-[#dbe6dc] max-h-[85vh] flex flex-col">
        {/* Modal Header */}
        <div className="flex items-center justify-between pb-4 border-b border-[#edf3ee]">
          <div>
            <h2 className="text-lg font-bold text-[#182a1e]">Lịch sử check-in cảm xúc</h2>
            <p className="text-xs text-[#5d7363]">Xem lại những khoảnh khắc bạn đã lắng nghe chính mình</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#576e5d] hover:text-[#18291e] hover:bg-[#eef4f0] rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content / List */}
        <div className="overflow-y-auto py-4 space-y-3 flex-1">
          {records.length === 0 ? (
            <div className="text-center py-12 text-[#647c6a]">
              <Calendar className="w-10 h-10 mx-auto mb-2 opacity-50 text-[#477a59]" />
              <p className="text-sm">Chưa có lượt check-in nào được ghi lại.</p>
              <p className="text-xs opacity-75 mt-1">Hoàn thành lượt check-in đầu tiên để xem tại đây!</p>
            </div>
          ) : (
            records.map((record) => {
              const q1 = record.answers[1];
              const q1Opt = QUESTIONS_DATA[0].options.find(
                (o) => o.id === (q1?.selectedOptionIds[0] || '')
              );
              const dateStr = new Intl.DateTimeFormat('vi-VN', {
                dateStyle: 'medium',
                timeStyle: 'short',
              }).format(new Date(record.timestamp));

              return (
                <div
                  key={record.id}
                  onClick={() => {
                    onSelectRecord(record);
                    onClose();
                  }}
                  className="p-4 rounded-2xl border border-[#e2ece3] hover:border-[#477a59] bg-[#fafcfb] hover:bg-[#f1f7f2] transition-all cursor-pointer flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-white border border-[#d6e5d9] flex items-center justify-center text-2xl shadow-2xs">
                      {q1Opt?.emoji || '🌱'}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-[#1a2d1f]">
                        {q1Opt?.label || 'Check-in'}
                      </div>
                      <div className="text-xs text-[#5f7565] flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3" />
                        <span>{dateStr}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {record.intensity && (
                      <span className="text-xs px-2.5 py-1 bg-[#dfebe1] text-[#2c5337] rounded-lg font-semibold">
                        {record.intensity}/10
                      </span>
                    )}
                    <ArrowRight className="w-4 h-4 text-[#758e7b] group-hover:text-[#477a59] group-hover:translate-x-1 transition-all" />
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        {records.length > 0 && (
          <div className="pt-3 border-t border-[#edf3ee] flex justify-between items-center text-xs">
            <span className="text-[#657a6b]">Tổng cộng: {records.length} lần</span>
            <button
              onClick={onClearHistory}
              className="inline-flex items-center gap-1.5 text-rose-600 hover:text-rose-700 py-1.5 px-3 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Xóa lịch sử</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
