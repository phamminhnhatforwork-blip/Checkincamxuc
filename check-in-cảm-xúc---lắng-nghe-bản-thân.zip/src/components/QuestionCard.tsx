import React, { useRef, useEffect } from 'react';
import { ArrowLeft, ArrowRight, Check, Sparkles } from 'lucide-react';
import { QuestionConfig, QuestionAnswer } from '../types';
import { SproutIcon } from './SproutIcon';

interface QuestionCardProps {
  question: QuestionConfig;
  totalQuestions: number;
  currentAnswer: QuestionAnswer;
  onUpdateAnswer: (answer: QuestionAnswer) => void;
  onNext: () => void;
  onPrev: () => void;
  isFirst: boolean;
  isLast: boolean;
}

export const QuestionCard: React.FC<QuestionCardProps> = ({
  question,
  totalQuestions,
  currentAnswer,
  onUpdateAnswer,
  onNext,
  onPrev,
  isFirst,
  isLast,
}) => {
  const customInputRef = useRef<HTMLInputElement>(null);

  // Toggle single or multiple option selection
  const handleSelectOption = (optionId: string, hasCustomInput?: boolean) => {
    let newSelected: string[] = [];

    if (question.type === 'single') {
      newSelected = [optionId];
    } else {
      if (currentAnswer.selectedOptionIds.includes(optionId)) {
        newSelected = currentAnswer.selectedOptionIds.filter((id) => id !== optionId);
      } else {
        newSelected = [...currentAnswer.selectedOptionIds, optionId];
      }
    }

    onUpdateAnswer({
      ...currentAnswer,
      questionId: question.id,
      selectedOptionIds: newSelected,
    });

    if (hasCustomInput && !currentAnswer.selectedOptionIds.includes(optionId)) {
      setTimeout(() => {
        customInputRef.current?.focus();
      }, 100);
    }
  };

  // Handle scale (1-10)
  const handleSelectScale = (value: number) => {
    onUpdateAnswer({
      ...currentAnswer,
      questionId: question.id,
      scaleValue: value,
      selectedOptionIds: [value.toString()],
    });
  };

  // Handle custom option text for "Khác: _______"
  const handleCustomTextChange = (text: string) => {
    const customOption = question.options.find((opt) => opt.hasCustomInput);
    let selected = [...currentAnswer.selectedOptionIds];
    if (customOption && !selected.includes(customOption.id) && text.trim().length > 0) {
      selected.push(customOption.id);
    }
    onUpdateAnswer({
      ...currentAnswer,
      questionId: question.id,
      selectedOptionIds: selected,
      customOptionText: text,
    });
  };

  // Determine if valid to proceed
  const canProceed =
    question.type === 'scale'
      ? !!currentAnswer.scaleValue || currentAnswer.selectedOptionIds.length > 0
      : currentAnswer.selectedOptionIds.length > 0;

  // Auto-scroll to top smoothly when question changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [question.id]);

  const customOption = question.options.find((opt) => opt.hasCustomInput);
  const isCustomOptionSelected = customOption && currentAnswer.selectedOptionIds.includes(customOption.id);

  return (
    <div className="w-full max-w-xl mx-auto px-4 py-6 md:py-10 animate-fade-in">
      {/* Top Navigation & Progress Bar */}
      <div className="mb-6 flex flex-col gap-3">
        <div className="flex items-center justify-between text-xs text-[#526857] font-medium">
          <button
            onClick={onPrev}
            className="inline-flex items-center gap-1.5 py-1 px-2.5 rounded-lg hover:bg-[#dfe8e0] text-[#36503c] transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{isFirst ? 'Trang chủ' : 'Câu trước'}</span>
          </button>

          <span className="bg-[#dfeae1] px-3 py-1 rounded-full text-[#385942] font-semibold">
            Câu {question.id} / {totalQuestions}
          </span>
        </div>

        {/* Progress Bar Track */}
        <div className="w-full h-1.5 bg-[#dbe6dc] rounded-full overflow-hidden">
          <div
            className="h-full bg-[#467a58] transition-all duration-300 rounded-full"
            style={{ width: `${(question.id / totalQuestions) * 100}%` }}
          />
        </div>
      </div>

      {/* Sprout & Question Title Header */}
      <div className="flex flex-col items-center text-center mb-6">
        <div className="mb-2">
          <SproutIcon className="w-10 h-10" />
        </div>
        <h1 className="text-xl md:text-2xl font-bold text-[#17271d] leading-snug max-w-md">
          {question.title}
        </h1>
        {question.subtitle && (
          <p className="text-xs md:text-sm text-[#546b5a] mt-1.5 max-w-sm">
            {question.subtitle}
          </p>
        )}
      </div>

      {/* Main White Card - identical styling as Welcome screen */}
      <div className="w-full bg-white rounded-3xl p-5 md:p-8 shadow-[0_10px_35px_rgba(27,48,34,0.06)] border border-[#e4ede5]">
        {/* Subtle top indicator bar */}
        <div className="w-14 h-1.5 bg-[#e3eae4] rounded-full mx-auto mb-5" />

        {/* Question Category / Step Overline */}
        <div className="text-xs font-bold tracking-wider text-[#487b5a] uppercase mb-4">
          {question.badge}
        </div>

        {/* --- SECTION: OPTIONS SELECTION --- */}
        <div className="mb-2">
          <label className="block text-xs font-semibold text-[#3d5743] uppercase tracking-wide mb-3">
            {question.type === 'multiple'
              ? 'Tùy chọn trắc nghiệm (chọn một hoặc nhiều):'
              : question.type === 'scale'
              ? 'Thang điểm đánh giá (từ 1 đến 10):'
              : 'Tùy chọn trắc nghiệm (chọn 1 đáp án):'}
          </label>

          {/* Scale 1-10 UI */}
          {question.type === 'scale' ? (
            <div className="space-y-5 py-2">
              {/* Large Active Number Callout */}
              <div className="flex flex-col items-center justify-center p-4 bg-[#f3f7f4] rounded-2xl border border-[#e1ece3]">
                <div className="text-4xl font-extrabold text-[#3d6e4d]">
                  {currentAnswer.scaleValue || currentAnswer.selectedOptionIds[0] || '—'}
                </div>
                <div className="text-xs font-medium text-[#506857] mt-1">
                  {Number(currentAnswer.scaleValue || currentAnswer.selectedOptionIds[0] || 0) <= 3
                    ? 'Mức độ nhẹ nhàng, thoáng qua'
                    : Number(currentAnswer.scaleValue || currentAnswer.selectedOptionIds[0] || 0) <= 6
                    ? 'Mức độ trung bình, có cảm nhận rõ'
                    : 'Mức độ mạnh mẽ, sâu sắc hoặc dữ dội'}
                </div>
              </div>

              {/* Number Grid 1 to 10 */}
              <div className="grid grid-cols-5 gap-2 sm:gap-2.5">
                {question.options.map((opt) => {
                  const val = Number(opt.label);
                  const isSelected =
                    currentAnswer.scaleValue === val ||
                    currentAnswer.selectedOptionIds.includes(opt.id);

                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleSelectScale(val)}
                      className={`h-12 rounded-xl font-bold text-base transition-all duration-200 flex items-center justify-center cursor-pointer border ${
                        isSelected
                          ? 'bg-[#477a59] text-white border-[#477a59] shadow-md scale-105'
                          : 'bg-[#f7faf7] text-[#2c4433] border-[#e2ece4] hover:bg-[#edf4ee] hover:border-[#cbdccf]'
                      }`}
                    >
                      {opt.label}
                    </button>
                  );
                })}
              </div>

              {/* Range Slider for quick drag */}
              <div className="px-1 pt-1">
                <input
                  type="range"
                  min="1"
                  max="10"
                  step="1"
                  value={currentAnswer.scaleValue || Number(currentAnswer.selectedOptionIds[0]) || 5}
                  onChange={(e) => handleSelectScale(Number(e.target.value))}
                  className="w-full h-2 bg-[#d7e4d9] rounded-lg appearance-none cursor-pointer accent-[#477a59]"
                />
                <div className="flex justify-between text-[11px] text-[#637a6a] mt-1 font-medium">
                  <span>1 - Rất nhẹ</span>
                  <span>5 - Vừa phải</span>
                  <span>10 - Rất dữ dội</span>
                </div>
              </div>
            </div>
          ) : (
            /* Standard Single / Multi Choice Options */
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {question.options.map((option) => {
                const isSelected = currentAnswer.selectedOptionIds.includes(option.id);

                return (
                  <button
                    key={option.id}
                    type="button"
                    onClick={() => handleSelectOption(option.id, option.hasCustomInput)}
                    className={`w-full text-left p-3.5 rounded-2xl border transition-all duration-200 flex items-center justify-between gap-3 cursor-pointer group ${
                      isSelected
                        ? 'bg-[#eff6f1] border-[#487c5a] text-[#1b3423] shadow-xs'
                        : 'bg-[#fafcfb] border-[#e4ede5] text-[#2c3d31] hover:bg-[#f2f7f3] hover:border-[#ccdccc]'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {option.emoji && (
                        <span className="text-xl flex-shrink-0">{option.emoji}</span>
                      )}
                      <span className={`text-sm md:text-[15px] leading-snug break-words ${isSelected ? 'font-semibold text-[#183120]' : 'font-normal'}`}>
                        {option.label}
                      </span>
                    </div>

                    {/* Check or Radio Indicator */}
                    <div
                      className={`w-5 h-5 rounded-${question.type === 'single' ? 'full' : 'md'} flex items-center justify-center flex-shrink-0 transition-colors border ${
                        isSelected
                          ? 'bg-[#477a59] border-[#477a59] text-white'
                          : 'border-[#ceddcf] bg-white group-hover:border-[#a8c4ab]'
                      }`}
                    >
                      {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                    </div>
                  </button>
                );
              })}
            </div>
          )}

          {/* If Question has "Khác" option and it is selected, or custom input */}
          {customOption && (
            <div
              className={`mt-3.5 p-3.5 rounded-2xl border transition-all ${
                isCustomOptionSelected
                  ? 'bg-[#eff6f1] border-[#487c5a]'
                  : 'bg-[#fafcfb] border-[#e4ede5]'
              }`}
            >
              <div className="flex items-center gap-2 mb-1.5">
                <span className="text-xs font-semibold text-[#3a5841]">
                  ✍️ Nhập lựa chọn khác cụ thể của bạn:
                </span>
              </div>
              <input
                ref={customInputRef}
                type="text"
                value={currentAnswer.customOptionText || ''}
                onChange={(e) => handleCustomTextChange(e.target.value)}
                placeholder="Nhập nội dung khác của bạn tại đây..."
                className="w-full px-3.5 py-2.5 text-sm bg-white rounded-xl border border-[#cfe0d2] text-[#1b2b20] placeholder-[#8ea394] focus:outline-none focus:ring-2 focus:ring-[#477a59]/30 focus:border-[#477a59]"
              />
            </div>
          )}
        </div>

        {/* Navigation Action Buttons */}
        <div className="mt-7 pt-5 border-t border-[#edf3ee] flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
          <button
            type="button"
            onClick={onPrev}
            className="w-full sm:w-auto px-5 py-3 rounded-2xl text-sm font-medium text-[#48634f] hover:bg-[#edf4ee] transition-colors cursor-pointer"
          >
            Quay lại
          </button>

          <button
            type="button"
            onClick={onNext}
            disabled={!canProceed}
            className={`w-full sm:w-auto inline-flex items-center justify-center gap-2 font-medium text-sm md:text-base py-3 px-6 rounded-2xl transition-all duration-200 shadow-sm cursor-pointer ${
              canProceed
                ? 'bg-[#477a59] hover:bg-[#3b684a] text-white hover:shadow-md active:scale-[0.98]'
                : 'bg-[#cbdcd0] text-[#748c7a] cursor-not-allowed'
            }`}
          >
            {isLast ? (
              <>
                <span>Xem tổng hợp kết quả</span>
                <Sparkles className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>Tiếp tục</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
