import React from 'react';

interface SproutIconProps {
  className?: string;
  size?: number;
}

export const SproutIcon: React.FC<SproutIconProps> = ({ className = 'w-12 h-12', size }) => {
  return (
    <div className={`inline-flex items-center justify-center select-none ${className}`} style={size ? { width: size, height: size } : undefined}>
      <svg
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full drop-shadow-xs"
      >
        {/* Soft natural glow */}
        <ellipse cx="32" cy="48" rx="16" ry="4" fill="#a4cfb0" fillOpacity="0.25" />

        {/* Stem */}
        <path
          d="M26 50 C28 42, 33 34, 38 27"
          stroke="#407753"
          strokeWidth="3.2"
          strokeLinecap="round"
        />

        {/* Left Leaf */}
        <path
          d="M34 32 C26 31, 19 35, 18 39 C17 44, 25 43, 31 38 Z"
          fill="url(#leftLeafGradient)"
        />

        {/* Right Top Leaf (larger, upward leaning like screenshot) */}
        <path
          d="M37 28 C37 18, 48 13, 56 16 C57 24, 48 29, 38 29 Z"
          fill="url(#rightLeafGradient)"
        />

        {/* Subtle leaf vein accents */}
        <path
          d="M35 29 C42 24, 49 20, 53 18"
          stroke="#396c4a"
          strokeWidth="1.2"
          strokeLinecap="round"
          strokeOpacity="0.4"
        />
        <path
          d="M31 37 C26 36, 22 38, 20 40"
          stroke="#396c4a"
          strokeWidth="1.0"
          strokeLinecap="round"
          strokeOpacity="0.4"
        />

        <defs>
          <linearGradient id="rightLeafGradient" x1="36" y1="28" x2="55" y2="15" gradientUnits="userSpaceOnUse">
            <stop stopColor="#4e8c5f" />
            <stop offset="0.6" stopColor="#67b278" />
            <stop offset="1" stopColor="#7ec88c" />
          </linearGradient>
          <linearGradient id="leftLeafGradient" x1="32" y1="36" x2="18" y2="40" gradientUnits="userSpaceOnUse">
            <stop stopColor="#437d55" />
            <stop offset="1" stopColor="#69b07a" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
};
