import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  Copy,
  Download,
  RotateCcw,
  Sparkles,
  Clock,
  Heart,
  Play,
  Pause,
  RefreshCw,
  HeartHandshake,
  Quote,
} from 'lucide-react';
import { QUESTIONS_DATA } from '../data/questions';
import { QuestionAnswer } from '../types';

interface SummaryScreenProps {
  answers: Record<number, QuestionAnswer>;
  onRestart: () => void;
}

export const SummaryScreen: React.FC<SummaryScreenProps> = ({ answers, onRestart }) => {
  const [copied, setCopied] = useState(false);
  const [activityChoice, setActivityChoice] = useState<'yes' | 'no' | null>(null);

  // Breathing Exercise State
  const [isBreathingActive, setIsBreathingActive] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'inhale' | 'hold' | 'exhale'>('inhale');
  const [phaseSeconds, setPhaseSeconds] = useState(4);
  const [breathCount, setBreathCount] = useState(0);

  const now = new Date();
  const formattedDate = new Intl.DateTimeFormat('vi-VN', {
    dateStyle: 'full',
    timeStyle: 'short',
  }).format(now);

  // Trigger gentle confetti on initial completion
  useEffect(() => {
    try {
      confetti({
        particleCount: 45,
        spread: 55,
        origin: { y: 0.6 },
        colors: ['#477a59', '#7bb48e', '#a8d5b5', '#eaf2ec'],
      });
    } catch {
      // ignore
    }
  }, []);

  // Breathing timer cycle
  useEffect(() => {
    if (!isBreathingActive) return;

    const interval = setInterval(() => {
      setPhaseSeconds((prev) => {
        if (prev > 1) {
          return prev - 1;
        }
        // Transition to next phase
        setBreathPhase((currentPhase) => {
          if (currentPhase === 'inhale') return 'hold';
          if (currentPhase === 'hold') return 'exhale';
          setBreathCount((c) => c + 1);
          return 'inhale';
        });
        return 4;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isBreathingActive]);

  // Helper to extract question labels
  const getSelectedLabels = (qId: number): { label: string; emoji?: string }[] => {
    const qConfig = QUESTIONS_DATA.find((q) => q.id === qId);
    const ans = answers[qId];
    if (!qConfig || !ans) return [];

    if (qConfig.type === 'scale') {
      const val = ans.scaleValue || ans.selectedOptionIds[0] || '5';
      return [{ label: `${val}/10` }];
    }

    return ans.selectedOptionIds.map((optId) => {
      const opt = qConfig.options.find((o) => o.id === optId);
      if (opt?.hasCustomInput && ans.customOptionText?.trim()) {
        return {
          label: `Khác: ${ans.customOptionText.trim()}`,
          emoji: opt.emoji,
        };
      }
      return {
        label: opt ? opt.label : optId,
        emoji: opt?.emoji,
      };
    });
  };

  const q1Labels = getSelectedLabels(1);
  const primaryMood = q1Labels[0]?.label || 'Bình yên';
  const primaryEmoji = q1Labels[0]?.emoji || '🌱';
  const scaleScore = answers[5]?.scaleValue || Number(answers[5]?.selectedOptionIds[0]) || 5;

  const q2Labels = getSelectedLabels(2);
  const q7Labels = getSelectedLabels(7);

  // Thoughtful message tailored specifically to the user who completed the check-in
  const getPersonalizedMessage = () => {
    const lower = primaryMood.toLowerCase();

    if (lower.includes('vui')) {
      return {
        title: 'Giữ trọn niềm vui và nguồn năng lượng ấm áp hôm nay',
        content:
          'Thật tuyệt vời khi bạn đang cảm nhận được sự rạng rỡ và tích cực từ bên trong! Niềm vui như một tia nắng ấm sưởi mát tâm hồn bạn. Hãy tận hưởng trọn vẹn khoảnh khắc này, ghi nhớ cảm giác dễ chịu này và lan tỏa nụ cười ấm áp đến những người xung quanh nhé.',
        affirmation:
          'Hạnh phúc không nằm ở đâu xa, nó đọng lại trong chính sự trân quý từng phút giây bình yên này.',
      };
    }
    if (lower.includes('lo lắng')) {
      return {
        title: 'Thả lỏng tâm trí, bạn đang làm rất tốt rồi',
        content:
          'Cảm giác lo âu thường đến khi chúng ta phải đối diện với nhiều điều chưa rõ ràng. Nhưng bạn ơi, bạn không cần phải tìm ra mọi lời giải ngay trong khoảnh khắc này. Hãy đặt nhẹ tay lên ngực, hít thở thật sâu và nhắc nhở bản thân rằng bạn hoàn toàn an toàn lúc này. Từng bước nhỏ một, mọi chuyện rồi sẽ ổn thôi.',
        affirmation:
          'Lo lắng không làm ngày mai bớt đi giông bão, nó chỉ lấy đi sức lực của hôm nay. Hãy cứ dịu dàng với chính mình.',
      };
    }
    if (lower.includes('căng thẳng')) {
      return {
        title: 'Bạn đã rất nỗ lực, hãy cho đôi vai được thả lỏng',
        content:
          'Những áp lực và trách nhiệm có thể đang đè nặng lên bạn, nhưng hãy nhớ rằng bạn đã cố gắng hết sức mình rồi! Thế giới sẽ không ngừng quay nếu bạn cho phép bản thân nghỉ ngơi 15 phút. Bạn xứng đáng được thả lỏng, hít thở và tái tạo lại năng lượng.',
        affirmation:
          'Đôi khi điều năng suất và ý nghĩa nhất bạn có thể làm chính là cho phép bản thân được nghỉ ngơi trọn vẹn.',
      };
    }
    if (lower.includes('buồn')) {
      return {
        title: 'Mọi cảm xúc của bạn đều xứng đáng được ôm ấp',
        content:
          'Nỗi buồn không làm bạn yếu đuối đi, mà cho thấy bạn là một người có trái tim chân thành và sâu sắc. Bạn không cần phải gượng ép mình phải tươi cười ngay. Hãy cho phép bản thân được lắng lại, uống một ngụm nước ấm và đối đãi với chính mình như với một người bạn thân thương nhất.',
        affirmation:
          'Cảm xúc đến rồi sẽ đi như những cơn mưa rào. Sau cơn mưa, bầu trời trong bạn sẽ lại sáng trong.',
      };
    }
    if (lower.includes('tức giận')) {
      return {
        title: 'Hạ nhiệt tâm trí và lắng nghe tiếng nói bên trong',
        content:
          'Sự tức giận là một phản ứng tự nhiên khi ranh giới hoặc mong muốn của bạn bị ảnh hưởng. Hãy dành cho mình một khoảng lặng ngắn để cơn nóng lắng dịu trước khi phản hồi hay quyết định điều gì. Bạn xứng đáng có được sự bình tĩnh và sáng suốt nhất.',
        affirmation:
          'Bình tĩnh không phải là kìm nén, mà là chọn cách phản ứng với sự tử tế và sáng suốt cho chính mình.',
      };
    }
    if (lower.includes('mệt mỏi')) {
      return {
        title: 'Lắng nghe tín hiệu nghỉ ngơi từ cơ thể bạn',
        content:
          'Cơ thể và tâm trí bạn đang gửi một thông điệp chân thành: xin được sạc lại năng lượng! Bạn không phải là một cỗ máy, và sự mệt mỏi là lời nhắc nhở bạn cần chăm sóc bản thân nhiều hơn. Đừng ngần ngại tạm gác lại những âu lo và cho mình một giấc ngủ thật êm đềm nhé.',
        affirmation:
          'Nghỉ ngơi không phải là thụt lùi, mà là sự chuẩn bị dịu dàng để ngày mai bạn bước đi vững vàng hơn.',
      };
    }
    return {
      title: 'Một khoảng lặng bình yên và quý giá cho tâm hồn',
      content:
        'Cảm giác bình lặng là một trạng thái rất đáng trân trọng. Đây là lúc tâm trí bạn đạt được sự cân bằng, không bị cuốn vào những xáo trộn mạnh mẽ. Hãy tận hưởng nhịp sống nhẹ nhàng này và lắng nghe từng nhịp thở tự nhiên của bản thân.',
      affirmation:
        'Sự bình an từ bên trong chính là điểm tựa vững chắc nhất của cuộc đời bạn.',
    };
  };

  const messageData = getPersonalizedMessage();

  // Generate plain text summary for copying / downloading
  const generateTextReport = () => {
    let report = `🌱 TỔNG HỢP CHECK-IN CẢM XÚC\n`;
    report += `Thời gian: ${formattedDate}\n`;
    report += `===================================\n`;
    report += `• Cảm xúc chủ đạo: ${primaryEmoji} ${primaryMood}\n`;
    report += `• Mức độ cường độ: ${scaleScore}/10\n`;
    if (q2Labels[0]) {
      report += `• Xuất hiện từ: ${q2Labels[0].label}\n`;
    }
    if (q7Labels[0]) {
      report += `• Điều bạn muốn nhất lúc này: ${q7Labels[0].emoji || ''} ${q7Labels[0].label}\n`;
    }
    report += `\n💌 THÔNG ĐIỆP & LỜI NHẮN GỬI ĐẾN BẠN:\n`;
    report += `${messageData.title}\n`;
    report += `${messageData.content}\n`;
    report += `"${messageData.affirmation}"\n`;
    report += `===================================\n`;
    report += `Lắng nghe và dịu dàng với chính mình mỗi ngày. 🌱\n`;
    return report;
  };

  const handleCopy = () => {
    const text = generateTextReport();
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const text = generateTextReport();
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `checkin_cam_xuc_${now.toISOString().slice(0, 10)}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="w-full max-w-xl mx-auto px-4 py-8 md:py-12 animate-fade-in">
      {/* Top Completion Header */}
      <div className="flex flex-col items-center text-center mb-8">
        <div className="w-12 h-12 rounded-2xl bg-[#dfeae1] flex items-center justify-center text-[#376947] mb-3 shadow-xs">
          <CheckCircle2 className="w-7 h-7" />
        </div>
        <div className="text-xs font-bold tracking-wider text-[#487b5a] uppercase mb-1">
          HOÀN THÀNH CHECK-IN
        </div>
        <h1 className="text-2xl md:text-3xl font-bold text-[#17271d] leading-tight">
          Tổng hợp cảm xúc của bạn
        </h1>
        <div className="inline-flex items-center gap-1.5 text-xs text-[#5f7564] mt-2">
          <Clock className="w-3.5 h-3.5" />
          <span>{formattedDate}</span>
        </div>
      </div>

      {/* Mood Showcase Card */}
      <div className="bg-white rounded-3xl p-6 md:p-8 shadow-[0_10px_35px_rgba(27,48,34,0.06)] border border-[#e4ede5] mb-6">
        <div className="w-14 h-1.5 bg-[#e3eae4] rounded-full mx-auto mb-6" />

        {/* Emotion Highlight Header */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4 pb-6 border-b border-[#edf3ee]">
          <div className="flex items-center gap-4 text-center sm:text-left">
            <div className="w-16 h-16 rounded-2xl bg-[#f0f6f2] border border-[#dce8df] flex items-center justify-center text-3xl shadow-xs">
              {primaryEmoji}
            </div>
            <div>
              <div className="text-xs uppercase tracking-wide text-[#59715e] font-semibold">
                Tâm trạng hiện tại
              </div>
              <div className="text-2xl font-bold text-[#1b2f21]">
                {primaryMood}
              </div>
              {q7Labels[0] && (
                <div className="text-xs text-[#566f5d] mt-1">
                  Đang cần: <span className="font-medium text-[#2d4d38]">{q7Labels[0].label}</span>
                </div>
              )}
            </div>
          </div>

          {/* Quick Intensity Meter */}
          <div className="w-full sm:w-48 bg-[#f4f7f4] p-3 rounded-2xl border border-[#e2ece4]">
            <div className="flex justify-between text-xs text-[#526a57] font-medium mb-1">
              <span>Mức độ cảm xúc</span>
              <span className="font-bold text-[#386545]">{scaleScore}/10</span>
            </div>
            <div className="w-full h-2 bg-[#d7e4d9] rounded-full overflow-hidden">
              <div
                className="h-full bg-[#477a59] rounded-full transition-all duration-500"
                style={{ width: `${(scaleScore / 10) * 100}%` }}
              />
            </div>
          </div>
        </div>

        {/* --- Ô THÔNG ĐIỆP VÀ LỜI NHẮN GỬI ĐẾN NGƯỜI LÀM --- */}
        <div className="mt-6 p-5 md:p-6 rounded-2xl bg-[#f3f8f4] border border-[#d8e8dc] shadow-xs">
          <div className="flex items-center gap-2.5 mb-2.5">
            <div className="w-8 h-8 rounded-xl bg-white border border-[#cfdfd2] flex items-center justify-center text-[#407451] shadow-2xs flex-shrink-0">
              <HeartHandshake className="w-4 h-4" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-[#487b5a] block">
                Thông điệp & Lời nhắn gửi đến bạn
              </span>
              <h3 className="text-[15px] md:text-base font-bold text-[#1a2e20]">
                {messageData.title}
              </h3>
            </div>
          </div>

          <p className="text-sm text-[#273a2d] leading-relaxed mt-3 whitespace-pre-line font-normal">
            {messageData.content}
          </p>

          <div className="mt-4 pt-3.5 border-t border-[#d8e7dc] flex items-center gap-2 text-xs text-[#395b43] italic">
            <Sparkles className="w-3.5 h-3.5 text-[#477a59] flex-shrink-0" />
            <span>"{messageData.affirmation}"</span>
          </div>
        </div>

        {/* --- QUESTION: "Bạn có muốn thử 1 hoạt động nhỏ để cải thiện cảm xúc không" --- */}
        <div className="pt-6 border-t border-[#edf3ee] mt-6">
          <div className="text-center mb-5">
            <h2 className="text-lg md:text-xl font-bold text-[#1a2d20] leading-snug">
              Bạn có muốn thử 1 hoạt động nhỏ để cải thiện cảm xúc không?
            </h2>
            <p className="text-xs md:text-sm text-[#5a7161] mt-1.5">
              Chỉ mất khoảng 1 phút, nhẹ nhàng và hoàn toàn theo ý muốn của bạn.
            </p>
          </div>

          {/* Two choices: Có & Chưa muốn */}
          <div className="grid grid-cols-2 gap-3 mb-5">
            <button
              type="button"
              onClick={() => {
                setActivityChoice('yes');
                setIsBreathingActive(true);
              }}
              className={`p-3.5 rounded-2xl font-semibold text-sm md:text-base transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 border ${
                activityChoice === 'yes'
                  ? 'bg-[#477a59] text-white border-[#477a59] shadow-md scale-[1.02]'
                  : 'bg-[#fafcfb] hover:bg-[#edf5ef] text-[#243d2c] border-[#d8e6db]'
              }`}
            >
              <Sparkles className="w-4 h-4" />
              <span>Có</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setActivityChoice('no');
                setIsBreathingActive(false);
              }}
              className={`p-3.5 rounded-2xl font-semibold text-sm md:text-base transition-all duration-200 cursor-pointer flex items-center justify-center gap-2 border ${
                activityChoice === 'no'
                  ? 'bg-[#5b6f60] text-white border-[#5b6f60] shadow-md scale-[1.02]'
                  : 'bg-[#fafcfb] hover:bg-[#edf5ef] text-[#3e5545] border-[#d8e6db]'
              }`}
            >
              <span>Chưa muốn</span>
            </button>
          </div>

          {/* Interactive outcome based on choice */}
          {activityChoice === 'yes' && (
            <div className="p-5 rounded-2xl bg-[#f2f7f3] border border-[#d5e5d8] animate-fade-in">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-[#3c6b4b]">
                  🌿 Bài tập thở 4 - 4 - 4 thư giãn
                </span>
                <span className="text-xs font-medium text-[#536d59]">
                  Đã thực hiện: {breathCount} lượt
                </span>
              </div>

              {/* Breathing Visual Guide */}
              <div className="flex flex-col items-center justify-center py-4">
                <div
                  className={`w-28 h-28 rounded-full border-4 flex flex-col items-center justify-center transition-all duration-1000 ${
                    breathPhase === 'inhale'
                      ? 'scale-115 border-[#477a59] bg-[#dbeae0] text-[#1b3423]'
                      : breathPhase === 'hold'
                      ? 'scale-110 border-[#7bb48e] bg-[#e6f1ea] text-[#24422e]'
                      : 'scale-90 border-[#8ea995] bg-[#edf4ee] text-[#36503c]'
                  }`}
                >
                  <span className="text-xs font-semibold uppercase tracking-wider">
                    {breathPhase === 'inhale'
                      ? 'Hít vào'
                      : breathPhase === 'hold'
                      ? 'Giữ hơi'
                      : 'Thở ra'}
                  </span>
                  <span className="text-2xl font-extrabold mt-0.5">{phaseSeconds}s</span>
                </div>

                <p className="text-xs text-[#486350] mt-4 text-center max-w-xs leading-relaxed">
                  {breathPhase === 'inhale' && 'Hít vào thật sâu bằng mũi, cảm nhận luồng khí mát lành...'}
                  {breathPhase === 'hold' && 'Giữ hơi thở nhẹ nhàng, thả lỏng trán và đôi bờ vai...'}
                  {breathPhase === 'exhale' && 'Thở ra chầm chậm qua miệng, buông bỏ mọi căng thẳng...'}
                </p>

                {/* Breathing Controls */}
                <div className="flex items-center gap-2 mt-4">
                  <button
                    type="button"
                    onClick={() => setIsBreathingActive(!isBreathingActive)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-white text-[#2a4533] border border-[#cfdfd2] hover:bg-[#edf4ee] transition-colors cursor-pointer shadow-2xs"
                  >
                    {isBreathingActive ? (
                      <>
                        <Pause className="w-3.5 h-3.5" />
                        <span>Tạm dừng</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        <span>Tiếp tục thở</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setPhaseSeconds(4);
                      setBreathPhase('inhale');
                      setBreathCount(0);
                      setIsBreathingActive(true);
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium text-[#46604e] hover:bg-white/60 transition-colors cursor-pointer"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Làm lại</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {activityChoice === 'no' && (
            <div className="p-4 rounded-2xl bg-[#f4f7f4] border border-[#dce6df] animate-fade-in flex items-start gap-3">
              <Heart className="w-5 h-5 text-[#477a59] flex-shrink-0 mt-0.5" />
              <div className="text-xs md:text-sm text-[#273d2e] leading-relaxed">
                <span className="font-semibold block mb-0.5">Không sao cả 🌱</span>
                Bạn không cần phải cố gắng làm gì thêm lúc này. Hãy cứ để bản thân được nghỉ ngơi thoải mái và lắng nghe chính mình theo cách tự nhiên nhất nhé.
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="bg-white rounded-3xl p-5 md:p-6 shadow-[0_10px_35px_rgba(27,48,34,0.06)] border border-[#e4ede5] flex flex-col sm:flex-row items-center justify-between gap-3">
        <button
          onClick={onRestart}
          className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-3 px-5 rounded-2xl text-sm font-medium text-[#3b5b43] bg-[#edf4ee] hover:bg-[#e1ece3] transition-colors cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>Làm lại check-in</span>
        </button>

        <div className="w-full sm:w-auto flex flex-col sm:flex-row items-center gap-2.5">
          <button
            onClick={handleDownload}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-3 px-4 rounded-2xl text-sm font-medium text-[#2d4734] border border-[#cfe0d3] hover:bg-[#edf5ef] transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Tải về file .txt</span>
          </button>

          <button
            onClick={handleCopy}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 py-3 px-5 rounded-2xl text-sm font-medium bg-[#477a59] hover:bg-[#3b684a] text-white shadow-sm hover:shadow-md transition-all cursor-pointer"
          >
            {copied ? (
              <>
                <CheckCircle2 className="w-4 h-4" />
                <span>Đã sao chép!</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4" />
                <span>Sao chép tóm tắt</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
