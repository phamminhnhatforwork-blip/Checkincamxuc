import React from 'react';
import { ArrowRight, History, Heart } from 'lucide-react';
import { SproutIcon } from './SproutIcon';

interface WelcomeScreenProps {
  onStart: () => void;
  onOpenHistory?: () => void;
  historyCount?: number;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onStart,
  onOpenHistory,
  historyCount = 0,
}) => {
  return (
    <div className="w-full max-w-md mx-auto px-4 py-8 md:py-14 flex flex-col items-center animate-fade-in">
      {/* Top sprout icon */}
      <div className="mb-4 transform hover:scale-105 transition-transform duration-300">
        <SproutIcon className="w-14 h-14" />
      </div>

      {/* Main Title */}
      <h1 className="text-2xl md:text-3xl font-bold text-[#17271d] text-center tracking-tight mb-2">
        Hôm nay bạn thế nào?
      </h1>

      {/* Subtitle */}
      <p className="text-[#516657] text-center text-sm md:text-base max-w-xs leading-relaxed mb-8 font-normal">
        Một phút để lắng nghe và chăm sóc cảm xúc của chính mình.
      </p>

      {/* Main White Card matching screenshot */}
      <div className="w-full bg-white rounded-3xl p-6 md:p-8 shadow-[0_10px_35px_rgba(27,48,34,0.06)] border border-[#e4ede5] relative transition-all duration-300">
        {/* Subtle top indicator bar */}
        <div className="w-16 h-1.5 bg-[#e3eae4] rounded-full mx-auto mb-6" />

        {/* Category Badge / Overline */}
        <div className="text-xs font-bold tracking-wider text-[#487b5a] uppercase mb-2">
          BẮT ĐẦU
        </div>

        {/* Card Title */}
        <h2 className="text-xl md:text-[22px] font-bold text-[#18281e] leading-snug mb-3">
          Bạn sẵn sàng dành một phút cho cảm xúc của mình chưa?
        </h2>

        {/* Card Subtitle */}
        <p className="text-[#55695b] text-sm md:text-base leading-relaxed mb-7">
          Không có câu trả lời đúng hay sai. Hãy chọn điều gần với bạn nhất.
        </p>

        {/* Primary CTA Button */}
        <div>
          <button
            onClick={onStart}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 bg-[#477a59] hover:bg-[#3b694b] active:scale-[0.98] text-white font-medium text-base py-3.5 px-6 rounded-2xl shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer"
          >
            <span>Bắt đầu check-in</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-0.5" />
          </button>
        </div>
      </div>

      {/* Footer / Gentle hints & History button */}
      <div className="mt-8 flex items-center justify-center gap-4 text-xs text-[#637768]">
        {historyCount > 0 && onOpenHistory && (
          <button
            onClick={onOpenHistory}
            className="inline-flex items-center gap-1.5 hover:text-[#2d4d38] transition-colors py-1 px-2.5 rounded-lg hover:bg-[#dfe9e1] cursor-pointer"
          >
            <History className="w-3.5 h-3.5" />
            <span>Đã check-in {historyCount} lần</span>
          </button>
        )}

        <div className="inline-flex items-center gap-1.5 opacity-80">
          <Heart className="w-3.5 h-3.5 text-[#477a59]" />
          <span>Dữ liệu được lưu an toàn trên máy bạn</span>
        </div>
      </div>
    </div>
  );
};
