export type SelectionType = 'single' | 'multiple' | 'scale';

export interface QuestionOption {
  id: string;
  label: string;
  emoji?: string;
  hasCustomInput?: boolean;
}

export interface QuestionConfig {
  id: number;
  badge: string;
  title: string;
  subtitle?: string;
  type: SelectionType;
  options: QuestionOption[];
  feedbackPlaceholder: string;
  scaleMin?: number;
  scaleMax?: number;
  scaleLabels?: { min: string; mid: string; max: string };
}

export interface QuestionAnswer {
  questionId: number;
  selectedOptionIds: string[];
  customOptionText?: string;
  feedbackNote?: string;
  scaleValue?: number;
}

export interface CheckInRecord {
  id: string;
  timestamp: string;
  answers: Record<number, QuestionAnswer>;
  primaryMood?: string;
  intensity?: number;
}
